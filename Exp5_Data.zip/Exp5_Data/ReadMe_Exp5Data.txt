
IMPORTANT DATA COLUMNS: 

recallResponse: participant input response for the recall test

corrName: name participants are being tested on in a given trial

AccuracyRecall: computer scoring of accuracy of participant’s recall response. Not used in analysis. 

AccuracyRecog: computer scoring of accuracy of participant’s recognition response. 

recallRT: response time as measured by first key press in recall task

recogRT: response time as measured by key press for multiple choice item in recognition task. 

subjIdx: participant ID. 

trials: test trial order for each ps. Ranging 1-60

block: block each item was tested in

encodingCondition: the name tag condition each item was given during encoding. 0 = synchronous, 1 = asynchronous


Rater 1: Rater 1 scores for participant accuracy in recall task

Rater 2: Rater 2 scores for participant accuracy in recall task

Rater 3: Rater 3 scores for participant accuracy in recall task

Rater composite: Score to indicate if at least one rater thought the response was accurate. 0 = no raters deemed the response accurate, 1 = at least one rater thought recall response was accurate
