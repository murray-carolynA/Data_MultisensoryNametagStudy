
IMPORTANT DATA COLUMNS: 

Name: the target name the participant is trying to remember

blocks.thisTrialN: block, ranging from 0-3

presentation.thisTrialN: stimulus order within encoding block, ranging 0-14

Testing.thisTrialN: stimulus order within test block, ranging 0-14

currentCond: name tag condition at encoding. 0 = no tag, 1 = tag

judgementResp.keys: Response to male/female face attention question. 1 = male, 2 = female

inputText: final text input by participant. 

Accuracy: original scoring by experimenters; not used in final data analysis.

key_resp_3.keys: full key stroke report for participants

key_resp_3.rt: response time for each key stroke made by participants

key_resp3_fin: response time for first keystroke in each response. Used in analysis. 

rating_resp.keys: confidence rating in name recall. Ranging from 1-5

rating_resp.rt: response time for confidence decision




Data Column with rater’s scores in each rater’s files:

Rater 1: Accuracy

Rater 2: Accuracy

Rater 3: ACCURACY